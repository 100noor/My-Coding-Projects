#include <iostream>
#include <conio.h>
#include <windows.h>
#include <ctime>
#include <fstream>
#include <stdexcept>


int highscore = 0;

#define WIN_WIDTH 70
#define SCREEN_WIDTH 90
#define SCREEN_HEIGHT 26
#define GAP_SIZE 6

using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

struct Pipe {
    int pos;
    int gap;
    bool active;
};

Pipe pipes[2];
char bird[2][6] = {
    { '/', '-', '-', 'o', '\\', ' ' },
    { '|', ' ', ' ', '_', ' ', '>' }
};

int birdPos = 6;
int score = 0;

void gotoxy(int x, int y);
void setcursor(bool visible, DWORD size);
void drawBorder();
void updateScore();
void genPipe(int ind);
void drawBird();
void eraseBird();
int collision();
void gameover();
void instructions();
void play();
void saveHighScore();
void loadHighScore();

int main() {
    setcursor(0 , 0);
    srand((unsigned)time(NULL));

    do {
        try {
            system("cls");
            gotoxy(10, 5); cout << " -------------------------- ";
            gotoxy(10, 6); cout << " |      Flappy Bird       | ";
            gotoxy(10, 7); cout << " --------------------------";
            gotoxy(10, 9);  cout << "1. Start Game";
            gotoxy(10, 10); cout << "2. Instructions";
            gotoxy(10, 11); cout << "3. Quit";
            gotoxy(10, 13); cout << "Select option: ";

            loadHighScore();
            gotoxy(WIN_WIDTH + 7, 6); cout << "High Score: " << highscore;

            char op = getche();
            if (op == '1') play();
            else if (op == '2') instructions();
            else if (op == '3') {
            system("cls");  
            exit(0);
}

            else throw invalid_argument("Invalid menu option selected.");

        } catch (const exception &e) {
            gotoxy(10, 15); cout << "Error: " << e.what();
            Sleep(1500);
        }
    } while (true);

    return 0;
}

void gotoxy(int x, int y) {
    CursorPosition.X = x;
    CursorPosition.Y = y;
    SetConsoleCursorPosition(console, CursorPosition);
}

void setcursor(bool visible, DWORD size) {
    if (size == 0) size = 20;
    CONSOLE_CURSOR_INFO lpCursor;
    lpCursor.bVisible = visible;
    lpCursor.dwSize = size;
    SetConsoleCursorInfo(console, &lpCursor);
}

void drawBorder() {
    for (int i = 0; i < SCREEN_WIDTH; i++) {
        gotoxy(i, 0); cout << "=";
        gotoxy(i, SCREEN_HEIGHT); cout << "=";
    }
    for (int i = 0; i < SCREEN_HEIGHT; i++) {
        gotoxy(0, i); cout << "||";
        gotoxy(SCREEN_WIDTH, i); cout << "||";
    }
    for (int i = 0; i < SCREEN_HEIGHT; i++) {
        gotoxy(WIN_WIDTH, i); cout << "||";
    }
}

void updateScore() {
    gotoxy(WIN_WIDTH + 7, 5); cout << "Score: " << score;
    gotoxy(WIN_WIDTH + 5, 9); cout << "High Score: " << highscore;
}

void genPipe(int ind) {
    try {
        int maxGapStart = SCREEN_HEIGHT - GAP_SIZE - 2;
        if (maxGapStart <= 0) throw runtime_error("Screen too small for pipe gap.");
        pipes[ind].gap = rand() % maxGapStart;
    } catch (const exception& e) {
        cout << "Error: " << e.what() << endl;
        exit(1);
    }
}

void drawBird() {
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 6; j++) {
            gotoxy(j + 2, i + birdPos); cout << bird[i][j];
        }
    }
}

void eraseBird() {
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 6; j++) {
            gotoxy(j + 2, i + birdPos); cout << " ";
        }
    }
}

void drawPipe(int ind) {
    if (!pipes[ind].active) return;
    int x = WIN_WIDTH - pipes[ind].pos;
    for (int y = 1; y < SCREEN_HEIGHT - 1; y++) {
        if (y < pipes[ind].gap || y > pipes[ind].gap + GAP_SIZE )  {
            gotoxy(x, y); cout << "*";
        }
    }
}

void erasePipe(int ind) {
    if (!pipes[ind].active) return;
    int x = WIN_WIDTH - pipes[ind].pos;
    for (int y = 1; y < SCREEN_HEIGHT - 1; y++) {
        gotoxy(x, y); cout << " ";
    }
}

int collision() {
    int x = WIN_WIDTH - pipes[0].pos;
    if (x <= 7 && x >= 2) {
        if (birdPos < pipes[0].gap || birdPos + 1 > pipes[0].gap + GAP_SIZE) {
            return 1;
        }
    }
    return 0;
}

void gameover() {
    try {
        if (score > highscore) saveHighScore();
        ofstream fout("highscore.txt", ios::app);
        if (!fout.is_open()) throw runtime_error("Unable to save score.");
        fout << "Score: " << score << endl;
        fout.close();
    } catch (const exception &e) {
        gotoxy(10, 15); cout << e.what();
    }

    system("cls");
    cout << "\n\t\t--------------------------";
    cout << "\n\t\t-------- Game Over -------";
    cout << "\n\t\t--------------------------\n\n";
    cout << "\t\tPress any key to go back to menu.";
    getch();
}

void instructions() {
    system("cls");
    cout << "Instructions";
    cout << "\n----------------";
    cout << "\n Press spacebar to make bird fly";
    cout << "\n\nPress any key to go back to menu";
    getch();
}

void loadHighScore() {
    try {
        ifstream infile("highscore.txt");
        if (!infile.is_open()) throw runtime_error("Highscore file not found.");
        infile >> highscore;
        if (infile.fail()) throw runtime_error("Invalid data in highscore file.");
        infile.close();
    } catch (...) {
        highscore = 0;
    }
}

void saveHighScore() {
    try {
        ofstream outfile("highscore.txt");
        if (!outfile.is_open()) throw runtime_error("Failed to open highscore file for writing.");
        outfile << score;
        outfile.close();
    } catch (const exception &e) {
        gotoxy(10, 20); cout << e.what();
    }
}

void play() {
    birdPos = 6;
    score = 0;
    pipes[0].active = true; pipes[0].pos = 4; genPipe(0);
    pipes[1].active = false; pipes[1].pos = 4;

    system("cls");
    drawBorder();
    updateScore();

    gotoxy(WIN_WIDTH + 5, 2); cout << "FLAPPY BIRD";
    gotoxy(WIN_WIDTH + 6, 4); cout << "----------";
    gotoxy(WIN_WIDTH + 6, 6); cout << "----------";
    gotoxy(WIN_WIDTH + 7, 12); cout << "Control ";
    gotoxy(WIN_WIDTH + 7, 13); cout << "-------- ";
    gotoxy(WIN_WIDTH + 2, 14); cout << " Spacebar = jump";

    gotoxy(10, 5); cout << "Press any key to start";
    getch();
    gotoxy(10, 5); cout << "                      ";

    while (true) {
        if (_kbhit()) {
            char ch = _getch();
            if (ch == 32 && birdPos > 0) {
                birdPos -= 3;
                if (birdPos < 0) birdPos = 0;
            }
            if (ch == 27) break;
        }

        if (birdPos <= 0) {
            gameover();
            return;
        }

        drawBird();
        drawPipe(0); drawPipe(1);

        if (collision()) {
            gameover();
            return;
        }

        Sleep(75);
        eraseBird();
        erasePipe(0); erasePipe(1);
        birdPos++;

        if (birdPos > SCREEN_HEIGHT - 1 ) {
            gameover();
            return;
        }

        if (pipes[0].active) pipes[0].pos += 2;
        if (pipes[1].active) pipes[1].pos += 2;

        if (pipes[0].pos >= 40 && !pipes[1].active) {
            pipes[1].active = true;
            pipes[1].pos = 4;
            genPipe(1);
        }

        if (pipes[0].pos > 68) {
            score++;
            updateScore();
            pipes[0] = pipes[1];
            pipes[1].active = false;
        }
    }
}
